import os
import requests
from bs4 import BeautifulSoup
import pandas as pd

input_file = 'input.dat'

# Delete the previous output.dat file if it exists
if os.path.isfile('output.dat'):
    os.remove('output.dat')

# Read the input file
with open(input_file, 'r') as file:
    input_data = [line.strip() for line in file.readlines()]
    # Delete the input file once it's read
    os.remove(input_file)

results = []
for crypto in input_data:
    response = requests.get(f'https://www.google.com/search?q={crypto}+price')
    soup = BeautifulSoup(response.text, 'html.parser')
    price = soup.find('div', {'class':'BNeawe iBp4i AP7Wnd'}).text
    results.append({crypto: price})

# Save the output to an output.dat file
with open('output.dat', 'w') as file:
    for result in results:
        file.write(str(result)+'\n')